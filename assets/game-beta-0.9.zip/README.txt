Welcome to 9Zip EXyCheats


Please dont cheat if you do cheat in an FNCS Cup you can get banned for ever or 12 months So PLEASE use an BackUP Fortnite Account


EULA= False


Make False to True to enable cheats




Made By the official 9Zip Team.


Beta 0.9 preRelease